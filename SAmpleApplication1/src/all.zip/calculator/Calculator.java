package calculator;

public class Calculator {
	int result;
	public int add (int num1,int num2)
	{
		result= num1+num2;
		return result;
		
	}
	public int add (int num1,int num2,int num3)
	{
		result= num1+num2+num3;
		return result;
		
	}
	
	public int subtract(int num1,int num2)
	{
		result = num1-num2;
	return result;
		
	}
	public int subtract(int num1,int num2,int num3)
	{
		result = num1-num2-num3;
	return result;
		
	}
}
