package com.training.first;
import com.training.second.*;
public class DemoProtected extends Demo2{
	int x=10;
	
	public DemoProtected()
	{
		//num1=1;
		//num2=2;
		/*num3=3;
		num4=4;
		
	}
	
	public void Demo() {
		System.out.println(x);
		System.out.println(num3);*/
	}

}
