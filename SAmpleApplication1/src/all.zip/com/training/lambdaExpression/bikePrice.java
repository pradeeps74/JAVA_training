package com.training.lambdaExpression;

public interface bikePrice {
	
void bikeDetails();
}

