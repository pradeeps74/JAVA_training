package com.training.second;

public interface Transactions {
	void transactionDetails();

}
