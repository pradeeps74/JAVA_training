package com.training.second;

public class ElectronicPhone extends Telephone{
	public ElectronicPhone()
	{
		member ="Digital";
	}
	public void  run()
	{
		super.ring();

	}

}
