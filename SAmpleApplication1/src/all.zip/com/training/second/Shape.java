package com.training.second;

import java.util.Scanner;

public abstract class Shape {
	
	public abstract void getDetails(Scanner sc);
	public abstract void displayDetails();
	public abstract void calculatedArea();

}
