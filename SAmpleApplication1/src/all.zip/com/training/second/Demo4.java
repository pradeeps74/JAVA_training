package com.training.second;

public class Demo4 {
	public static void main(String[] args) {
		ElectronicPhone ep = new ElectronicPhone();
		ep.run();
	}

}
