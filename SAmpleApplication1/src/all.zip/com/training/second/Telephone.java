package com.training.second;

public class Telephone {
	protected String member;
	public void ring() {
		 System.out.println("Ringing the "+ member+"PHONE");
	}

}
