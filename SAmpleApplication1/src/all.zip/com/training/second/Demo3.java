package com.training.second;

public class Demo3 {
	public static void main(String[] args) {
		Person p = new Student();
		p.transactionDetails();
		/*System.out.println(p.display("pradhu","nesapakkam" , 9789698765l));
		Person pe = new Person("love","Heart",98798777l);
		System.out.println(pe.display());
		Person p1= new Student();
		System.out.println(p1.display());
		System.out.println(p1.display("Peace","Nature", 7755577755l));
		Person p2= new Doctor();
		System.out.println(p2.display());
		System.out.println(p2.display("Pain","Lonely", 1110111011l));*/
	}

}
